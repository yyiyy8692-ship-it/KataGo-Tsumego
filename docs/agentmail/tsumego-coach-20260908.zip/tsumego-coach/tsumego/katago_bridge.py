# -*- coding: utf-8 -*-
"""可选的 KataGo GTP 桥（路线一 x 路线二 的混合点）。

用途：
1) order_hints：用 KataGo 的策略/访问数为 df-pn 提供根局面着法
   排序，加速证明收敛（策略引导的证明搜索）；
2) analyze：在 df-pn 无法证明时，给出"非证明"的参考意见。

需要本机安装 KataGo（https://github.com/lightvector/KataGo），
并准备 GTP 配置与网络权重文件。
"""
import queue
import subprocess
import threading
import time

from .board import OPP, COLS, coord_str


def _to_point(s, size):
    s = s.strip().upper()
    if not s or s == "PASS" or s[0] not in COLS or not s[1:].isdigit():
        return None
    c = COLS.index(s[0])
    r = size - int(s[1:])
    return (r, c) if 0 <= r < size else None


def parse_analyze(line, size):
    """解析 kata-analyze 的 info 行。

    返回 (着法信息列表, ownership 列表或 None)。
    """
    toks = line.split()
    moves, cur, owner = [], None, None
    i = 0
    while i < len(toks):
        t = toks[i]
        if t == "info":
            if cur is not None:
                moves.append(cur)
            cur = {}
            i += 1
            continue
        if cur is not None:
            if t == "move":
                cur["move"] = toks[i + 1]
                i += 2
                continue
            if t in ("visits", "winrate", "scoreLead", "prior", "utility", "lcb", "order"):
                try:
                    cur[t] = float(toks[i + 1])
                    i += 2
                    continue
                except (ValueError, IndexError):
                    pass
        if t == "ownership":
            j, vals = i + 1, []
            while j < len(toks):
                try:
                    vals.append(float(toks[j]))
                    j += 1
                except ValueError:
                    break
            owner = vals
            i = j
            continue
        i += 1
    if cur is not None:
        moves.append(cur)
    return moves, owner


class KataGoBridge:
    def __init__(self, exe, config, model, size):
        cmd = [exe, "gtp", "-config", config, "-model", model]
        self.proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            bufsize=1,
        )
        self.q = queue.Queue()
        threading.Thread(target=self._reader, daemon=True).start()
        self._cmd("name", timeout=120)  # 握手 + 等待模型加载
        self._cmd(f"boardsize {size}")
        self._cmd("komi 0")
        self.size = size
        self._synced_key = None

    # ---------- GTP 基础 ----------

    def _reader(self):
        for line in self.proc.stdout:
            self.q.put(line.rstrip("\n"))

    def _drain(self):
        while True:
            try:
                self.q.get_nowait()
            except queue.Empty:
                return

    def _cmd(self, c, timeout=60):
        self.proc.stdin.write(c + "\n")
        self.proc.stdin.flush()
        out, deadline = [], time.time() + timeout
        while time.time() < deadline:
            try:
                line = self.q.get(timeout=max(0.05, deadline - time.time()))
            except queue.Empty:
                break
            if line.startswith("info"):  # 残留的分析输出
                continue
            if line == "":
                if out:
                    break
                continue
            out.append(line)
        if not out:
            raise RuntimeError(f"GTP 无响应: {c}")
        if out[0].startswith("?"):
            raise RuntimeError(f"GTP 错误: {' / '.join(out)}")
        return "\n".join(out[1:])

    # ---------- 棋局同步 ----------

    def _sync(self, board):
        key = (board.zhash, len(board.moves), board.initial_to_move)
        if self._synced_key == key:
            return
        self._cmd("clear_board")
        color = board.initial_to_move
        for m in board.moves:
            if m is PASS:
                self._cmd(f"play {color} pass")
            else:
                self._cmd(f"play {color} {coord_str(board.size, m)}")
            color = OPP[color]
        self._synced_key = key

    # ---------- 分析 ----------

    def analyze(self, board, seconds=5.0):
        """返回 (着法信息列表, ownership)。winrate 为当前行棋方视角。"""
        self._sync(board)
        self.proc.stdin.write("kata-analyze 20 ownership true\n")
        self.proc.stdin.flush()
        best, deadline = "", time.time() + seconds
        while time.time() < deadline:
            try:
                line = self.q.get(timeout=0.2)
            except queue.Empty:
                continue
            if line.startswith("info"):
                best = line
        # 发送新命令以终止分析流，然后清理
        self.proc.stdin.write("name\n")
        self.proc.stdin.flush()
        time.sleep(0.3)
        self._drain()
        if not best:
            return [], None
        return parse_analyze(best, self.size)

    def order_hints(self, board, seconds=4.0):
        """根局面着法排序提示：{(r, c): rank}，rank 越小越优先。"""
        infos, _ = self.analyze(board, seconds)
        hints = {}
        for rank, info in enumerate(infos):
            mv = info.get("move")
            if not mv or str(mv).upper() == "PASS":
                continue
            p = _to_point(str(mv), self.size)
            if p is not None and p in board.region:
                hints[p] = rank
        return hints
