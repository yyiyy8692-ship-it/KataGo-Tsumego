# -*- coding: utf-8 -*-
"""深度优先证明数搜索（df-pn, Nagai 2002）死活求解器。

求证目标（攻方视角）：
- PROVEN（守方死）：攻方存在强制手段，最终吃掉守方全部棋子；
- DISPROVEN（守方活）：无论攻方怎么下，都无法吃掉守方棋子；
- UNKNOWN：超出节点预算，或局面过于复杂。

算法要点：
- AND/OR 树：攻方行棋 = OR 节点（只需一个取胜着法），
  守方行棋 = AND 节点（守方需所有应法都失败攻方才赢）；
- 证明数 pn / 反证数 dn：OR 节点 pn=min(子), dn=sum(子)；AND 对称；
- 阈值 (pnT, dnT) 迭代加深，深度优先潜入最有希望的子节点；
- 置换表按 (棋子哈希, 行棋方) 复用子节点当前估计值。

严格性说明：当整个搜索过程中没有触发"禁全同"过滤
（solver.ko_filtered == 0）时，所有局面的合法着法集与路径无关，
置换表复用是精确的，证明结果在围棋规则下严格成立；
ko_filtered > 0 时结果按"禁全同（超劫）"规则成立，需留意劫争。
"""
import time

from .board import PASS, OPP

INF = 1 << 30
PROVEN = "proven"        # 守方死
DISPROVEN = "disproven"  # 守方活
UNKNOWN = "unknown"

MAX_LOOP = 200000  # 单节点 while 循环保险丝


class SearchAborted(Exception):
    pass


class DFPNSolver:
    def __init__(self, board, node_limit=1000000, root_order=None, time_limit=60.0):
        self.root = board.clone()
        self.node_limit = node_limit
        self.nodes = 0
        self.tt = {}      # key -> (pn, dn)
        self.child = {}   # (key, move) -> (pn, dn)
        self.ko_filtered = 0
        self.root_order = root_order or {}
        self.time_limit = time_limit
        self.elapsed = 0.0
        self._t0 = 0.0

    # ---------- 对外接口 ----------

    def solve(self):
        self._t0 = time.time()
        b = self.root.clone()
        key = b.key()
        try:
            self._search(b, INF, INF, frozenset([key]))
        except SearchAborted:
            pass
        self.elapsed = time.time() - self._t0
        pn, dn = self.tt.get(key, (None, None))
        if pn is None:
            return UNKNOWN, None
        if pn == 0:
            return PROVEN, self._pv(b, True)
        if dn == 0:
            return DISPROVEN, self._pv(b, False)
        return UNKNOWN, None

    # ---------- 核心搜索 ----------

    def _search(self, b, pnT, dnT, path):
        self.nodes += 1
        if self.nodes > self.node_limit:
            raise SearchAborted
        if self.nodes % 4096 == 0 and time.time() - self._t0 > self.time_limit:
            raise SearchAborted

        key = b.key()
        if b.no_defenders():
            self.tt[key] = (0, INF)
            return
        if b.double_pass():
            self.tt[key] = (INF, 0)
            return

        moves, ko = b.legal_moves(path)
        if ko:
            self.ko_filtered += ko
        if not moves:
            self.tt[key] = (INF, 0)
            return
        moves = self._sorted(b, moves)

        attacker_to_move = b.to_move == b.attacker
        loops = 0
        while True:
            loops += 1
            if loops > MAX_LOOP:
                raise SearchAborted

            vals = [self.child.get((key, m), (1, 1)) for m in moves]
            if attacker_to_move:
                pn = min(v[0] for v in vals)
                dn = min(sum(v[1] for v in vals), INF)
            else:
                pn = min(sum(v[0] for v in vals), INF)
                dn = min(v[1] for v in vals)

            if pn == 0:
                self.tt[key] = (0, INF)
                return
            if dn == 0:
                self.tt[key] = (INF, 0)
                return
            if pn >= pnT or dn >= dnT:
                self.tt[key] = (pn, dn)
                return

            # 选子节点并计算子阈值（Nagai 公式）
            n = len(moves)
            if attacker_to_move:
                idx = min(range(n), key=lambda i: vals[i][0])
                p2 = min((vals[i][0] for i in range(n) if i != idx), default=INF)
                cpnT = pnT if p2 >= INF else min(pnT, p2 + 1)
                cdnT = min(INF, dnT - dn + vals[idx][1])
            else:
                idx = min(range(n), key=lambda i: vals[i][1])
                d2 = min((vals[i][1] for i in range(n) if i != idx), default=INF)
                cdnT = dnT if d2 >= INF else min(dnT, d2 + 1)
                cpnT = min(INF, pnT - pn + vals[idx][0])

            m = moves[idx]
            u = b.play(m)
            ckey = b.key()
            self._search(b, cpnT, cdnT, path | {ckey})
            b.undo_move(u)
            self.child[(key, m)] = self.tt.get(ckey, (1, 1))

    # ---------- 排序 ----------

    def _sorted(self, b, moves):
        """着法排序：KataGo 提示 > 邻近少气棋链 > 邻子数；pass 放最后。"""
        if len(moves) <= 2:
            return moves
        enemy = OPP[b.to_move]

        def key(m):
            if m is PASS:
                return (9, 1 << 30, 99, 0)
            ro = self.root_order.get(m)
            libs = b.min_adjacent_chain_libs(m, enemy)
            libs = 99 if libs is None else libs
            adj = len(b.stone_neighbors(m))
            if ro is None:
                return (1, 1 << 30, libs, -adj)
            return (0, ro, libs, -adj)

        return sorted(moves, key=key)

    # ---------- 主变化线 ----------

    def _pv(self, b, want_proven):
        """提取主变化。want_proven=True 沿证明线（杀棋线），
        False 沿反证线（做活线）。返回 [(行棋方, 着法, 提子数)]。"""
        b = self.root.clone()
        line = []
        for _ in range(400):
            if b.no_defenders() or b.double_pass():
                break
            key = b.key()
            moves, _ = b.legal_moves(None)
            found = False
            best_rank, best_m = None, None
            for m in moves:
                v = self.child.get((key, m))
                if v is None:
                    continue
                pn, dn = v
                if want_proven:
                    ok = pn == 0
                    main = dn if b.to_move == b.attacker else -dn
                else:
                    ok = dn == 0
                    main = pn if b.to_move == b.defender else -pn
                if not ok:
                    continue
                # 平级时优先展示落子（pass 线索价值低）
                rank = (main, 1 if m is PASS else 0)
                if not found or rank < best_rank:
                    found, best_rank, best_m = True, rank, m
            if not found:
                break
            u = b.play(best_m)
            caps = 0 if u[0] is PASS else sum(len(s) for s in u[2])
            line.append((OPP[b.to_move], best_m, caps))
        return line
