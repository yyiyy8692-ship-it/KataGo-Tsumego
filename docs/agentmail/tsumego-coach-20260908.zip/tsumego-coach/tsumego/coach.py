# -*- coding: utf-8 -*-
"""死活教练 REPL：df-pn 证明为主，KataGo 混合增强为辅。"""
import time

from .board import PASS, IllegalMove, coord_str, parse_coord
from .dfpn import DISPROVEN, DFPNSolver, PROVEN, UNKNOWN

COLOR_NAME = {"X": "黑", "O": "白"}

HELP = """命令：
  show            显示当前局面（· 为可落子区域，. 为区域外）
  solve [节点数]   证明当前局面的死活（df-pn，给出强制变化线）
  hint            给出当前行棋方的最佳着手（优先证明解）
  best            引擎直接走一步（证明解优先，否则 KataGo）
  play D4|pass    你来落子
  undo            悔一手
  moves           列出全部合法着法
  kata [秒]       KataGo 分析当前局面（需启动时连接）
  quit            退出"""


class TsumegoCoach:
    def __init__(self, problem, bridge=None, node_limit=1000000):
        self.problem = problem
        self.board = problem.make_board()
        self.bridge = bridge
        self.node_limit = node_limit
        self._undo_stack = []
        self._solved_for = None
        self._solution = None

    # ---------- 求解 ----------

    def solve_current(self, node_limit=None):
        key = self.board.key()
        if self._solved_for == key:
            return self._solution
        order = None
        if self.bridge is not None:
            try:
                order = self.bridge.order_hints(self.board)
            except Exception as e:
                print(f"（KataGo 排序提示不可用，改用内置启发式：{e}）")
        solver = DFPNSolver(
            self.board, node_limit or self.node_limit, root_order=order
        )
        result, pv = solver.solve()
        self._solution = {
            "result": result,
            "pv": pv,
            "nodes": solver.nodes,
            "ko": solver.ko_filtered,
            "time": solver.elapsed,
        }
        self._solved_for = key
        return self._solution

    def verdict_text(self, sol):
        d = COLOR_NAME[self.board.defender]
        a = COLOR_NAME[self.board.attacker]
        if sol["result"] == PROVEN:
            return f"【已证明】{d}死：{a}有强制手段吃掉全部{d}棋子。"
        if sol["result"] == DISPROVEN:
            return f"【已证明】{d}净活：{a}无论如何都无法吃掉{d}棋。"
        return "【未能证明】超出计算预算，或局面含复杂循环（劫争）。"

    # ---------- 提示 ----------

    def hint_move(self):
        """返回 (着法, 说明) 或 (None, 说明)。"""
        sol = self.solve_current()
        b = self.board
        d = COLOR_NAME[b.defender]
        a = COLOR_NAME[b.attacker]
        pv = sol["pv"] or []

        if sol["result"] == PROVEN:
            if b.to_move == b.attacker:
                if pv:
                    return pv[0][1], f"{a}杀着（已证明）："
                return None, f"已证明{d}死，但变化线为空。"
            if pv:
                return pv[0][1], f"{d}已无法做活（已证明），最强抵抗："
            return None, f"已证明{d}死。"
        if sol["result"] == DISPROVEN:
            if b.to_move == b.defender:
                if pv:
                    return pv[0][1], f"{d}做活要点（已证明）："
                return None, f"已证明{d}净活。"
            if pv:
                return pv[0][1], f"{a}无法杀{d}（已证明），最顽强的尝试："
            return None, f"已证明{d}净活。"

        # UNKNOWN -> KataGo 参考
        if self.bridge is not None:
            try:
                infos, _ = self.bridge.analyze(b, seconds=5.0)
                for info in infos:
                    mv = str(info.get("move", ""))
                    if mv.upper() == "PASS":
                        continue
                    p = self._coord_to_point(mv)
                    if p is not None:
                        return p, "KataGo 参考（非证明）："
            except Exception as e:
                return None, f"KataGo 分析失败：{e}"
        return None, "无建议（可加大 --nodes 重试）。"

    def _coord_to_point(self, s):
        try:
            p = parse_coord(self.board.size, s)
        except ValueError:
            return None
        if p is PASS:
            return None
        if p not in self.board.region or self.board.grid[p[0]][p[1]] != ".":
            return None
        return p

    # ---------- 输出 ----------

    def print_solution(self, sol):
        print(self.verdict_text(sol))
        print(
            f"  搜索节点 {sol['nodes']}，用时 {sol['time']:.2f}s"
            + (f"，禁全同过滤 {sol['ko']} 次" if sol["ko"] else "")
        )
        if sol["ko"] == 0:
            print("  严格性：本次证明未涉及劫/循环禁着，结论在规则下严格成立。")
        else:
            print("  严格性：证明过程中出现过禁全同（劫/循环）分支，结论按禁全同规则成立。")
        if sol["result"] in (PROVEN, DISPROVEN):
            self.print_pv(sol["pv"])

    def print_pv(self, pv):
        if not pv:
            print("  （无主要变化）")
            return
        parts = []
        for i, (color, move, caps) in enumerate(pv, 1):
            s = COLOR_NAME[color] + (
                coord_str(self.board.size, move) if move is not PASS else "停一手"
            )
            if caps:
                s += f"(提{caps}子)"
            parts.append(f"{i}.{s}")
        print("  主变化：" + "  ".join(parts))
        # 演变终局图
        b = self.board.clone()
        for _, move, _caps in pv:
            try:
                b.play(move)
            except IllegalMove:
                break
        print("  演变结果：")
        for ln in b.render().splitlines():
            print("    " + ln)
        if b.no_defenders():
            print("    -> 守方棋子全部被提（攻方目标达成）")

    # ---------- REPL ----------

    def repl(self):
        p = self.problem
        print(f"题目：{p.title}  先行：{COLOR_NAME[p.to_move]}  "
              f"守方：{COLOR_NAME[p.defender]}（X）  攻方：{COLOR_NAME[p.attacker]}（O）")
        print("（输入 help 查看命令）\n")
        print(self.board.render())
        print()
        while True:
            try:
                line = input("tsumego> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not line:
                continue
            parts = line.split()
            cmd, args = parts[0].lower(), parts[1:]
            try:
                if cmd in ("quit", "exit", "q"):
                    break
                elif cmd == "help":
                    print(HELP)
                elif cmd == "show":
                    print(self.board.render())
                    print(f"轮到 {COLOR_NAME[self.board.to_move]} 落子")
                elif cmd == "solve":
                    limit = int(args[0]) if args else None
                    sol = self.solve_current(limit)
                    self.print_solution(sol)
                elif cmd == "hint":
                    mv, note = self.hint_move()
                    if mv is None:
                        print(note)
                    else:
                        print(note + coord_str(self.board.size, mv))
                elif cmd == "best":
                    mv, note = self.hint_move()
                    if mv is None:
                        print(note)
                    else:
                        print(note + coord_str(self.board.size, mv))
                        self._do_play(mv)
                elif cmd in ("play", "p"):
                    if not args:
                        print("用法：play D4 或 play pass")
                        continue
                    if self.board.game_over():
                        print("对局已结束（棋子已提净或双方停手）。")
                        continue
                    mv = parse_coord(self.board.size, args[0])
                    self._do_play(mv)
                elif cmd == "pass":
                    if self.board.game_over():
                        print("对局已结束。")
                        continue
                    self._do_play(PASS)
                elif cmd == "undo":
                    if not self._undo_stack:
                        print("没有可悔的棋。")
                        continue
                    u = self._undo_stack.pop()
                    self.board.undo_move(u)
                    self._solved_for = None
                    print(self.board.render())
                elif cmd == "moves":
                    moves, _ = self.board.legal_moves(None)
                    ss = [
                        coord_str(self.board.size, m) if m is not PASS else "pass"
                        for m in moves
                    ]
                    print("  " + " ".join(ss))
                elif cmd == "kata":
                    if self.bridge is None:
                        print("未连接 KataGo（启动时用 --katago/--config/--model 指定）。")
                        continue
                    secs = float(args[0]) if args else 5.0
                    infos, _owner = self.bridge.analyze(self.board, seconds=secs)
                    if not infos:
                        print("（无分析输出）")
                        continue
                    print(f"  KataGo 参考（当前行棋方 {COLOR_NAME[self.board.to_move]}，winrate 为其视角）：")
                    for info in infos[:6]:
                        mv = str(info.get("move", "?"))
                        wr = info.get("winrate")
                        v = info.get("visits")
                        sl = info.get("scoreLead")
                        print(
                            f"    {mv:5s} winrate "
                            f"{wr if wr is None else f'{wr:.3f}'}  "
                            f"visits {v if v is None else int(v)}  "
                            f"scoreLead {sl if sl is None else f'{sl:+.1f}'}"
                        )
                else:
                    print(f"未知命令：{cmd}（help 查看命令）")
            except IllegalMove as e:
                print(f"不合法：{e}")
            except ValueError as e:
                print(f"输入错误：{e}")

    def _do_play(self, mv):
        u = self.board.play(mv)
        self._undo_stack.append(u)
        self._solved_for = None
        print(self.board.render())
        status = ""
        if self.board.no_defenders():
            status = "  -> 守方棋子已全部被提。"
        elif self.board.double_pass():
            status = "  -> 双方停手，局面终止。"
        print(f"轮到 {COLOR_NAME[self.board.to_move]} 落子{status}")
