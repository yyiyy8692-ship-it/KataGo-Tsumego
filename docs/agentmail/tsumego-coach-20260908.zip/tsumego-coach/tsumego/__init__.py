# -*- coding: utf-8 -*-
"""绝对正确死活教练：df-pn 证明搜索 + 可选 KataGo 混合增强。"""

from .board import Board, PASS
from .dfpn import DFPNSolver, PROVEN, DISPROVEN, UNKNOWN
from .problem import Problem, load_problem
from .coach import TsumegoCoach

__version__ = "0.1.0"

__all__ = [
    "Board", "PASS", "DFPNSolver", "PROVEN", "DISPROVEN", "UNKNOWN",
    "Problem", "load_problem", "TsumegoCoach",
]
