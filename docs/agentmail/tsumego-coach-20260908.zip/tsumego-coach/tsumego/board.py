# -*- coding: utf-8 -*-
"""小型围棋棋盘引擎，专为封闭区域死活（tsumego）求解设计。

规则语义（与真实围棋规则一致，且是"证明正确"的基础）：
- 落子仅限 region（题目区域）内的空点，或停一手（pass）；
- 提子优先于自杀判定：先提掉无气的对方棋链，再检查己方链是否有气；
- 路径级"禁止全局同形"（positional superko）：禁止走出与祖先局面
  （棋子 + 行棋方）完全相同的局面，用于处理劫与循环；
- 双方连续停一手且守方仍有子在盘上 => 判守方活（双停手终局）。

坐标约定：内部 (r, c)，r=0 为最上行；显示时列用 A-T（跳过 I），
行号 = size - r，与标准围棋坐标一致（A1 在左下角）。
"""
import random

PASS = None
EMPTY, BLACK, WHITE = ".", "X", "O"
OPP = {"X": "O", "O": "X"}

COLS = "ABCDEFGHJKLMNOPQRST"  # 围棋坐标跳过 I

_tables = {}


def zobrist(size):
    """确定性种子的 Zobrist 哈希表（按棋盘尺寸缓存）。"""
    if size not in _tables:
        rng = random.Random(20260908)
        _tables[size] = {
            color: [[rng.getrandbits(64) for _ in range(size)] for _ in range(size)]
            for color in (BLACK, WHITE)
        }
    return _tables[size]


def coord_str(size, p):
    r, c = p
    return f"{COLS[c]}{size - r}"


def parse_coord(size, s):
    """把 'D4' / 'pass' 解析为 (r, c) 或 PASS。"""
    s = s.strip().upper()
    if s == "PASS":
        return PASS
    if len(s) < 2 or s[0] not in COLS or not s[1:].isdigit():
        raise ValueError(f"无法识别坐标: {s!r}")
    c = COLS.index(s[0])
    r = size - int(s[1:])
    if not (0 <= r < size and 0 <= c < size):
        raise ValueError(f"坐标超出棋盘: {s!r}")
    return (r, c)


class IllegalMove(Exception):
    pass


class Board:
    def __init__(self, size, grid, region, attacker, defender, to_move):
        self.size = size
        self.grid = [list(row) for row in grid]
        self.region = frozenset(region)
        self.attacker = attacker      # 攻方（想杀棋的一方）
        self.defender = defender      # 守方（想做活的一方）
        self.to_move = to_move
        self.initial_to_move = to_move
        self.moves = []
        tbl = zobrist(size)
        h = 0
        for r in range(size):
            for c in range(size):
                v = self.grid[r][c]
                if v in (BLACK, WHITE):
                    h ^= tbl[v][r][c]
        self.zhash = h

    # ---------- 基础 ----------

    def clone(self):
        b = object.__new__(Board)
        b.size = self.size
        b.grid = [row[:] for row in self.grid]
        b.region = self.region
        b.attacker = self.attacker
        b.defender = self.defender
        b.to_move = self.to_move
        b.initial_to_move = self.initial_to_move
        b.moves = list(self.moves)
        b.zhash = self.zhash
        return b

    def key(self):
        """局面键 = (棋子哈希, 行棋方)。用于置换表与禁全同判定。"""
        return (self.zhash, self.to_move)

    def _nbrs(self, r, c):
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < self.size and 0 <= nc < self.size:
                yield nr, nc

    def _chain(self, r, c):
        """返回 (棋子列表, 气集合)。"""
        color = self.grid[r][c]
        stones, libs, stack, seen = [(r, c)], set(), [(r, c)], {(r, c)}
        while stack:
            x, y = stack.pop()
            for nx, ny in self._nbrs(x, y):
                v = self.grid[nx][ny]
                if v == EMPTY:
                    libs.add((nx, ny))
                elif v == color and (nx, ny) not in seen:
                    seen.add((nx, ny))
                    stones.append((nx, ny))
                    stack.append((nx, ny))
        return stones, libs

    # ---------- 终局判定 ----------

    def no_defenders(self):
        """守方棋子全部被提 => 攻方目标达成。"""
        d = self.defender
        for row in self.grid:
            if d in row:
                return False
        return True

    def double_pass(self):
        return (
            len(self.moves) >= 2
            and self.moves[-1] is PASS
            and self.moves[-2] is PASS
        )

    def game_over(self):
        return self.no_defenders() or self.double_pass()

    # ---------- 落子 / 悔子 ----------

    def play(self, move):
        """落子或停一手。返回 undo 信息（供 undo_move），非法则抛 IllegalMove。

        规则顺序：放子 -> 提对方无气链 -> 己方无气则非法（自杀）。
        """
        if move is PASS:
            self.to_move = OPP[self.to_move]
            self.moves.append(PASS)
            return (PASS,)
        r, c = move
        if not (0 <= r < self.size and 0 <= c < self.size):
            raise IllegalMove("坐标越界")
        if (r, c) not in self.region:
            raise IllegalMove("落点不在题目区域内")
        if self.grid[r][c] != EMPTY:
            raise IllegalMove("落点已有棋子")

        color = self.to_move
        enemy = OPP[color]
        tbl = zobrist(self.size)
        h = self.zhash ^ tbl[color][r][c]
        self.grid[r][c] = color

        captured = []
        for nr, nc in self._nbrs(r, c):
            if self.grid[nr][nc] == enemy:
                stones, libs = self._chain(nr, nc)
                if not libs:
                    for sr, sc in stones:
                        self.grid[sr][sc] = EMPTY
                        h ^= tbl[enemy][sr][sc]
                    captured.append(stones)

        stones, libs = self._chain(r, c)
        if not libs:  # 自杀：回滚
            self.grid[r][c] = EMPTY
            for stones_ in captured:
                for sr, sc in stones_:
                    self.grid[sr][sc] = enemy
            raise IllegalMove("禁着点（自杀）")

        self.zhash = h
        self.to_move = enemy
        self.moves.append(move)
        return (move, color, captured)

    def undo_move(self, u):
        if u[0] is PASS:
            self.to_move = OPP[self.to_move]
            self.moves.pop()
            return
        move, color, captured = u
        r, c = move
        enemy = OPP[color]
        tbl = zobrist(self.size)
        h = self.zhash ^ tbl[color][r][c]
        self.grid[r][c] = EMPTY
        for stones in captured:
            for sr, sc in stones:
                self.grid[sr][sc] = enemy
                h ^= tbl[enemy][sr][sc]
        self.zhash = h
        self.to_move = color
        self.moves.pop()

    # ---------- 着法生成 ----------

    def legal_moves(self, path=None):
        """返回 (合法着法列表, 因禁全同被过滤的着法数)。

        path 为当前搜索路径上的局面键集合；若某着法走完后局面键在
        path 中（劫 / 循环重现），则该着法被禁止。pass 永远合法。
        """
        moves = [PASS]
        ko = 0
        empties = [p for p in sorted(self.region) if self.grid[p[0]][p[1]] == EMPTY]
        for p in empties:
            try:
                u = self.play(p)
            except IllegalMove:
                continue
            bad = path is not None and self.key() in path
            self.undo_move(u)
            if bad:
                ko += 1
                continue
            moves.append(p)
        return moves, ko

    # ---------- 启发式辅助 ----------

    def stone_neighbors(self, p):
        return [n for n in self._nbrs(*p) if self.grid[n[0]][n[1]] != EMPTY]

    def min_adjacent_chain_libs(self, p, color):
        """p 周围 color 色棋链的最少气数（无则 None）。"""
        best, seen = None, set()
        for n in self._nbrs(*p):
            if self.grid[n[0]][n[1]] == color and n not in seen:
                stones, libs = self._chain(*n)
                seen.update(stones)
                if best is None or len(libs) < best:
                    best = len(libs)
        return best

    # ---------- 显示 ----------

    def render(self):
        lines = ["   " + " ".join(COLS[: self.size])]
        for r in range(self.size):
            cells = []
            for c in range(self.size):
                v = self.grid[r][c]
                if v == EMPTY:
                    v = "\u00b7" if (r, c) in self.region else "."
                cells.append(v)
            lines.append(f"{self.size - r:2d} " + " ".join(cells))
        return "\n".join(lines)
