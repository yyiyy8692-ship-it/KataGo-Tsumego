# -*- coding: utf-8 -*-
"""死活题目文件解析。

文件格式（# 开头为注释）：

    title 直三（黑先活）
    size 7
    tom X          # 先行方：X=黑(守方) / O=白(攻方)
    result alive   # 可选：dead / alive，供 --selftest 核对
    board:
    . . . . . . .   <- 最上行（行号 = size）
    . . . . . . .
    . . . . . . .
    . O O O . . .
    O X X X O . .
    O . . . O . .   <- 最下行（第 1 行）

符号：X=黑（守方），O=白（攻方墙），.=空点，*=显式标记区域点。
区域（可落子范围）默认自动计算：从守方棋子出发，沿空点/守方棋子
泛洪，被攻方棋子挡住——即"封闭眼位 + 守方棋子"。若棋盘中出现
'*'，则区域 = '*' 点 ∪ 守方棋子点（适用于眼位内有攻方子的题型）。
"""
import os
from collections import deque

from .board import Board, EMPTY, BLACK, WHITE

ALLOWED = {".", "X", "O", "*"}


class Problem:
    def __init__(self, title, size, rows, to_move, expected=None):
        self.title = title
        self.size = size
        self.rows = rows
        self.to_move = to_move
        self.expected = expected
        self.defender = BLACK  # 约定：X 为守方
        self.attacker = WHITE  # 约定：O 为攻方

    def make_board(self):
        grid = [list(row) for row in self.rows]
        region = self._region(grid)
        return Board(self.size, grid, region, self.attacker, self.defender, self.to_move)

    def _region(self, grid):
        size = self.size
        starred = {
            (r, c)
            for r in range(size)
            for c in range(size)
            if grid[r][c] == "*"
        }
        for r, c in starred:
            grid[r][c] = EMPTY
        defenders = {
            (r, c)
            for r in range(size)
            for c in range(size)
            if grid[r][c] == self.defender
        }
        if starred:
            return starred | defenders
        # 自动泛洪：从守方棋子出发，穿过空点与守方棋子
        region = set(defenders)
        dq = deque(defenders)
        while dq:
            r, c = dq.popleft()
            for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                nr, nc = r + dr, c + dc
                if (
                    0 <= nr < size
                    and 0 <= nc < size
                    and (nr, nc) not in region
                    and grid[nr][nc] in (EMPTY, self.defender)
                ):
                    region.add((nr, nc))
                    dq.append((nr, nc))
        return region


def load_problem(path):
    meta, rows, in_board = {}, [], False
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower() == "board:":
                in_board = True
                continue
            if in_board:
                rows.append(line.split())
            else:
                kv = line.split(None, 1)
                meta[kv[0].lower()] = kv[1].strip() if len(kv) > 1 else ""

    if "size" not in meta:
        raise ValueError(f"{path}: 缺少 size 字段")
    size = int(meta["size"])
    if len(rows) != size or any(len(r) != size for r in rows):
        raise ValueError(f"{path}: 棋盘行/列数与 size={size} 不符")
    for r in rows:
        bad = [s for s in r if s not in ALLOWED]
        if bad:
            raise ValueError(f"{path}: 非法符号 {bad}")

    to_move = meta.get("tom", "X").upper()
    if to_move not in ("X", "O"):
        raise ValueError(f"{path}: tom 必须是 X 或 O")
    expected = (meta.get("result") or "").lower() or None
    if expected is not None and expected not in ("dead", "alive"):
        raise ValueError(f"{path}: result 必须是 dead / alive")
    title = meta.get("title") or os.path.basename(path)
    return Problem(title, size, rows, to_move, expected)
