# 拍照死活题批改 · 端到端产品技术方案

> 版本:v1.0(2026-09-08)
> 目标读者:负责实现的 AI 编程助手 / 开发者。本文档为可直接落地的完整规格:模块边界、接口签名、数据契约、算法步骤、验收标准均已明确。
> 前置依赖:本仓库 `tsumego-coach`(判题引擎,已通过 8/8 自测)——本方案**复用其全部引擎代码,不修改现有模块**。

---

## 0. 产品定义

**一句话**:学生在死活题书上用笔写 `1 2 3 4 5…` 解题,手机拍照 → 系统识别印刷题面与手写手数 → 证明级引擎逐手批改 → 输出"第几手错、正解是什么" → 沉淀错题本。

**用户故事**:
1. 我做完书上 5 道题,拍照上传;
2. 30 秒内看到每道题:我写的每一手,哪手对、哪手错、错在第几手、正解要点是什么;
3. 错题自动进错题本,附我的原始笔迹标注图。

**场景边界(V1)**:
- 输入:单题照片(用户裁剪或拍照即单题),书页平整或轻微倾斜;或电子题集截图;
- 题面:局部棋盘(6~19 路),印刷黑子(实心圆)与白子(空心圆),可能含星位点;
- 手写:阿拉伯数字 1~99,铅笔/圆珠笔/黑笔,写在交点上或交点附近;
- 先行方与目标("黑先杀/白先杀/黑先活/白先活")由用户在 UI 二选一/四选一(书上通常有标注);
- **不做(V1)**:劫标记(`201@47` 式提子重下)、一页多题自动切分、手写汉字、卷曲书页(V2/V3)。

---

## 1. 系统架构与数据流

```
[照片] → M1 预处理 → M2 网格重建 → M3 印刷棋子识别 ┐
                                     ├→ M5 题面重建(Problem + moves)
              M1 → M4 手写分离与数字识别 ────────────┘
                                        ↓
                     M6 逐手批改(复用 tsumego-coach: Board/DFPNSolver/KataGoBridge)
                                        ↓
                     M7 报告与错题本(JSON + 叠加可视化 + SQLite)
```

**核心数据契约**(全部放在新包 `photo/contracts.py`):

```python
from dataclasses import dataclass, field

@dataclass
class GridResult:            # M2 输出
    board_size: int          # 路数 N(棋盘线数-1),如 9/13/19 或局部 6..12
    intersections: list      # (r,c) -> (x,y) 像素坐标,r=0 为最上行;shape (N,N)
    corners: list            # 棋盘四角像素坐标(左上起顺时针)
    spacing: float           # 平均格距(像素)
    method: str              # 'hough'(平整) | 'unet'(V2 卷曲)
    confidence: float        # 0..1

@dataclass
class StoneCell:             # M3 输出
    r: int; c: int
    state: str               # 'black' | 'white' | 'empty' | 'star'
    confidence: float

@dataclass
class MoveMark:              # M4 输出
    r: int; c: int           # 归属交点(行 r=0 为最上行,与题目 txt 一致)
    number: int              # 手数 1..99
    digit_boxes: list        # 数字连通域 bbox 列表(调试用)
    confidence: float

@dataclass
class GradedMove:            # M7 输出单元
    number: int
    color: str               # 'black'|'white'(按书的真实颜色)
    vertex: str              # 如 "D4"(SGF 风格坐标,A~T 跳过 I)
    verdict: str             # 'correct'|'wrong'|'illegal'|'engine_unknown'
    note: str                # 引擎说明,如 "证明:此手后黑活不成立;正解 E5"

@dataclass
class GradeReport:           # M7 输出
    title: str
    first_mover: str; goal: str       # 用户选择:'black'/'white' + 'kill'/'live'
    engine_verdict: str               # 题面基准解:'defender_alive'|'defender_dead'
    moves: list                       # List[GradedMove]
    first_wrong: int | None           # 首个错手的手数
    overlay_path: str                 # 叠加可视化图路径
    raw: dict                         # 完整中间结果(调试/审计)
```

---

## 2. 模块规格

新增 Python 包 `photo/`,与现有 `tsumego/` 平级:

```
tsumego-coach/
├── run.py                # 扩展 --photo 入口(增量修改,不动现有 REPL/selftest)
├── tsumego/              # 现有引擎,零修改
├── photo/                # 新增
│   ├── contracts.py      # 上述 dataclass
│   ├── ingest.py         # M1
│   ├── grid.py           # M2
│   ├── stones.py         # M3
│   ├── digits.py         # M4(含数字分类器训练/推理)
│   ├── reconstruct.py    # M5
│   ├── grade.py          # M6
│   └── report.py         # M7
├── models/digit_cnn.pt   # M4 模型权重
└── tests/photo/          # 合成回归测试集
```

### M1 预处理(`ingest.py`)

- **接口**:`def preprocess(img_bgr: np.ndarray) -> np.ndarray`
- **步骤**:EXIF 方向转正 → 长边缩放至 1600px(保留比例)→(可选)`cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))` 光照均衡 → 返回处理图与缩放比例(坐标回映射用,封装为 `ScaleTracker`)。
- V2 追加:四边形透视矫正(`cv2.getPerspectiveTransform`)。
- **验收**:任何输入不抛异常;缩放后网格线仍可被 M2 检出。

### M2 棋盘网格重建(`grid.py`)

- **接口**:`def detect_grid(img: np.ndarray) -> GridResult`
- **算法(平整场景,纯 OpenCV,无训练)**:
  1. 灰度化 → 自适应阈值(`cv2.adaptiveThreshold`,blockSize≈格距,需多尺度尝试 15/21/31)→ 形态学闭运算;
  2. `cv2.HoughLinesP` 取线段,按角度聚类为横/竖两组(容差 ±10°);
  3. 每组按截距 1D 聚类(类间距 > 0.5×中位间距),得 m 条横线、n 条竖线 → `board_size = (m-1, n-1)` 若相等且在 5..19;否则失败;
  4. 相邻线求交得 `intersections[r][c]`(亚像素:对交点 5×5 邻域质心细化);
  5. 置信度 = 线聚类紧密度 × 网格等距性(行列间距的标准差/均值)。
- **失败降级**:置信度 < 0.6 → 返回 None,上层提示"请压平书页重拍"。
- **V2(卷曲)**:U-Net 分割棋盘线(参考 goboard-segmentation:3→1 通道、BCELoss、polyline 标签),后处理霍夫求交;训练增强必须补齐:随机透视 + 弹性形变(TPS 网格扭曲)± 亮度/阴影。
- **验收**:合成平整集 100 张,交点 F1 ≥ 0.99;轻微倾斜(<15°)F1 ≥ 0.95。

### M3 印刷棋子识别(`stones.py`)

- **接口**:`def detect_stones(img: np.ndarray, grid: GridResult) -> list[StoneCell]`
- **算法**:对每个交点取 patch(边长 = 1.0×格距):
  1. `black`(实心圆):中心 0.3R 圆内灰度均值 < 0.35×全图棋盘底色亮度,且暗像素填充率 > 60%;
  2. `white`(空心圆):环形模板——外环(0.6~0.85R)暗、内芯(0~0.4R)亮,响应 > 阈值;
  3. `star`(星位点):实心但半径 < 0.25×格距(明显小于棋子);
  4. 阈值用 Otsu 自适应,置信度取响应强度。
- **验收**:合成集 100 张(含不同印刷风格 ≥ 5 种),棋子三分类准确率 ≥ 98%,星位点误判为棋子 = 0。

### M4 手写分离与数字识别(`digits.py`)

- **接口**:
  ```python
  def extract_handwriting(img, grid, stones) -> np.ndarray          # 手写层 mask
  def detect_number_marks(hand_layer, grid) -> list[MoveMark]       # 检测+分类+归属
  ```
- **手写分离(三信号取并集后清理)**:
  1. **印刷抑制**:M2 线段 + M3 棋子圆在原图上画成印刷 mask,膨胀 2px 后置零;
  2. **颜色通道**:铅笔灰的手写像素 RGB 三通道方差小且非纯黑(印刷为纯黑/网点);圆珠笔(蓝黑)用 B-R 通道差;
  3. **笔画形态**:手写笔画宽度方差大、走向随机(印刷线只有横竖 2 个方向)→ 用方向滤波保留非横竖笔画。
  - V1 允许保守:宁漏勿错,漏掉的数字由 UI 让用户补点。
- **数字检测**:手写层连通域(`cv2.connectedComponentsWithStats`),过滤:面积 ∈ [0.003, 0.15]×格距²、宽高比 ∈ [0.25, 4];相邻域(间距 < 0.4×格距)合并为多digit候选(处理 10+ 两位数)。
- **数字分类**:轻量 CNN,输入 32×32 灰度:
  ```
  Conv(3×3,16)-BN-ReLU → MaxPool → Conv(3×3,32)-BN-ReLU → MaxPool
  → Conv(3×3,64)-BN-ReLU → GAP → FC(64→11)   # 类别:0-9 + 'not_digit'
  ```
  - **训练数据纯合成**(无需人工标注):干净题面扫描/截图作底版 → 在交点邻域随机贴 MNIST 风格数字(随机仿射 ±15°、缩放 0.8~1.3、亮度/噪声、铅笔灰/蓝黑两种着色)→ 自动生成 image+box+label,量级 10 万张,CPU 数小时可训完;
  - 负样本:棋盘线残段、星位点、印刷噪声。
  - 推理:对每个候选框分类,`not_digit` 或置信度 < 0.8 丢弃。
- **归属**:数字框中心 → 最近交点,距离 < 0.6×格距 才接受;一个交点最多一个手数,冲突取置信度最高。
- **验收**:合成集单字准确率 ≥ 97%;端到端(整题手数序列完全正确)≥ 90%。

### M5 题面重建(`reconstruct.py`)

- **接口**:
  ```python
  def build_problem(stones: list[StoneCell], grid: GridResult,
                    first_mover: str, goal: str) -> Problem
  def build_moves(marks: list[MoveMark], first_mover: str) -> list[tuple]
  ```
- **颜色映射(关键约定,必须严格执行)**:引擎 `tsumego/problem.py` 硬约定 **X=守方(求活方)、O=攻方(杀棋方)**,且 `defender=BLACK`。因此:
  - `goal == 'live'` 且 `first_mover='black'` → 黑求活:识别的 black→`X`,white→`O`,题面 `tom X`;
  - `goal == 'kill'` 且 `first_mover='white'` → 白杀黑:黑仍为守方 → 同上映射,`tom O`;
  - `goal == 'live'` 且 `first_mover='white'` → 白求活:**白为守方** → white→`X`,black→`O`,题面 `tom X`;
  - `goal == 'kill'` 且 `first_mover='black'` → 黑杀白:white→`X`,black→`O`,`tom O`;
  - 星位点 → `.`(仅在 star 标记处保留 `*`?否——`*` 是区域标记,星位点一律 `.`);
  - 区域:不写 `*`,交给 `Problem._region` 自动泛洪;若解题数字落在泛洪区外(罕见),在 raw 中记 warning。
- **手数颜色**:`color(i) = first_mover if i % 2 == 1 else 对方`。
- **合法性预检**:用 `Board` 逐手试下:重复落子/落在棋子上 → 该手标 `illegal`,后续手照常(引擎逐手独立求解不受影响)。
- **验收**:构造 20 个已知题面+手数的合成用例 → `build_problem` 输出与手工编写的 txt 完全等价(可 `load_problem` 后逐格对比)。

### M6 逐手批改(`grade.py`)——本产品灵魂

- **接口**:
  ```python
  def grade(problem: Problem, moves: list[tuple],
            node_limit: int = 200000) -> GradeReport
  ```
- **算法(证明级逐手验证)**:
  1. **基准解**:对题面初始局面 `B0` 跑 `DFPNSolver` 得 `V0 ∈ {PROVEN(守方死), DISPROVEN(守方活), UNKNOWN}`;UNKNOWN → 全题标 `engine_unknown`,降级 KataGo(若可用)给参考意见,**不编造结论**;
  2. **逐步验证**:记 `V(B)` 为局面 B 的 df-pn 三态解。对学生的每一手 `m_i`:
     - 合法性:`Board.play` 失败 → `illegal`;
     - 落子后局面 `B_i` 再解,得 `V_i`;
     - **判定规则**:`m_i` 为 `correct` ⟺ `V_i == V_{i-1}`(该手未让行棋方阵营的结果变差);`V_i ≠ V_{i-1}` → `wrong`,note 附上 `B_{i-1}` 的引擎 PV 首着作为"正解";
     - 注意交替视角:守方行棋时"变差"= 活→死;攻方行棋时"变差"= 死→活。规则统一为上式,无需分支;
  3. **性能**:局部封闭题单次求解 8~500 节点(见 selftest),k 手序列 ≈ k+1 次求解,Python 秒级;
  4. **引擎结果映射回真实颜色**:报告层把 `X/O` 还原为书上的 black/white(`PROVEN` = 守方死)。
- **验收(批改正确性是硬指标)**:构造 30 个"学生答案"用例(全对/第 i 手错/非法手/打劫),批改结论与人工棋理复盘 100% 一致;批改模块不得引入引擎之外的新判断逻辑。

### M7 报告与错题本(`report.py`)

- **接口**:`def make_report(...) -> GradeReport;def render(report, img) -> overlay_path;def save_to_db(report, db_path)`
- **输出**:
  1. **JSON**(`GradeReport` 序列化);
  2. **叠加可视化**:原图上画网格(绿)、识别棋子(半透明)、手写数字框(按 verdict 着色:绿=对/红=错/灰=未识别),错手处标引擎正解箭头;
  3. **错题本**:SQLite(`mistakes.db`),表 `records(id, ts, title, goal, first_mover, engine_verdict, first_wrong, moves_json, overlay_path, source_img)`。
- **验收**:渲染图人眼可核对;错题本可按 first_wrong 不为空查询。

---

## 3. CLI / 入口契约

`run.py` 增量扩展(**不改动现有 `--selftest` / REPL 任何行为**):

```bash
# 拍照批改(核心新入口)
python run.py --photo IMG_001.jpg --first black --goal kill
python run.py --photo page1.png --first white --goal live --out report.json

# 参数
--first {black,white}   先行方(书上"黑先/白先")
--goal  {kill,live}     先行方目标(杀/活)
--photo PATH            单题照片
--out PATH              报告 JSON 输出路径(默认 report.json)
--overlay PATH          叠加图输出路径(默认 overlay_<输入名>.jpg)
--review                输出后进入人工确认 REPL(对漏检数字手动补:v D4=3)
```

退出码:0 成功;2 参数/文件错误;3 识别失败(网格/低置信度,提示重拍);4 引擎 unknown(部分降级)。

---

## 4. 数据与训练策略

| 模型 | 数据来源 | 量级 | 备注 |
|---|---|---|---|
| 数字 CNN(M4) | 纯合成:干净题面底版 + MNIST 风格数字随机贴 | 10 万张 | 唯一需要训练的模型,CPU 可训 |
| 线分割 U-Net(V2) | 合成渲染棋盘 + 卷曲/透视/阴影增强 | 2 千渲染底版 × 增强 | 参考 goboard-segmentation(AGPL,只借思路勿抄代码) |

**测试集构建**:自购 2~3 本死活题书(如《围棋死活大全》入门卷),每本选 20 题:先拍"干净页"(无手写)建立题面金标,再请棋友按给定手数书写,拍照得端到端金标。所有测试图入 `tests/photo/`,标注 JSON 随图存。

---

## 5. 实施路线

| 阶段 | 范围 | 预估 |
|---|---|---|
| P1 MVP | M1(无透视)+ M2(hough)+ M3 + M4(合成 CNN)+ M5 + M6 + M7(JSON+叠加图),CLI 跑通端到端 | 1~2 周 |
| P2 产品化 | FastAPI + Web UI:上传→预览识别结果→人工修正(点选补数字/改棋子)→批改报告;错题本页面 | 1~2 周 |
| P3 鲁棒性 | 透视矫正、卷曲 U-Net、一页多题检测(YOLO 小图检测)、两位数/劫标记 | 持续 |

P1 的 Milestone 验收 = 第 6 节全绿。

---

## 6. 验收标准(P1)

1. 合成集(100 张,含 ≥5 种印刷风格):
   - 网格交点 F1 ≥ 0.99;棋子三分类 ≥ 98%;数字单字 ≥ 97%;端到端序列全对 ≥ 90%;
2. 真实照片集(≥40 题,平整):端到端序列全对 ≥ 75%,其余允许 `--review` 人工修正后批改;
3. 批改逻辑:30 个构造用例与人工复盘 100% 一致;
4. 现有 `python run.py --selftest` 保持 8/8 通过(零回归);
5. 单题端到端(不含 UI)< 10 秒(CPU)。

---

## 7. 风险与降级

| 风险 | 信号 | 降级动作 |
|---|---|---|
| 书页卷曲严重 | M2 置信度 < 0.6 | 提示压平重拍;V2 上 U-Net |
| 手写与印刷难分 | 手写层像素量异常 | UI 人工点选补数字(`--review`) |
| 数字粘连/两位数 | 检测框合并 | 单字优先;10+ 题目少见,标记待确认 |
| 引擎超预算 | UNKNOWN | 明确输出"引擎未能证明",不瞎判;可附 KataGo 参考 |
| 题面非封闭形 | df-pn 结论与棋理不符 | raw 中输出区域泛洪示意图,提示题面识别可能有误 |

---

## 8. 与现有代码的对接清单(编程助手必读)

- `from tsumego import load_problem, Board, DFPNSolver, PROVEN, DISPROVEN, TsumegoCoach` —— 只读复用;
- `Problem` 构造签名:`Problem(title, size, rows, to_move, expected)`,`rows` 为 `list[list[str]]`(字符 `X/O/./ *`),`to_move ∈ {'X','O'}`,**X 恒为守方**;
- `Board(problem.size, grid, region, attacker, defender, to_move)`:一般通过 `problem.make_board()` 获得,`region` 自动泛洪;
- `DFPNSolver(board, node_limit).solve()` → `(result, pv)`,pv 为证明主变线(着法序列);
- `RESULT_CN = {PROVEN: "黑死", DISPROVEN: "黑活"}` 中的"黑"指守方 X,报告时映射回真实颜色;
- 坐标系:题目 txt 最上行为 r=0;SGF 顶点 `A1` 起于左下,转换时注意翻转(M5 内实现 `to_vertex(r, c, size)`)。
