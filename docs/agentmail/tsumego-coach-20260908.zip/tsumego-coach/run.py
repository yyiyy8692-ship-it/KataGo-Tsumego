# -*- coding: utf-8 -*-
"""命令行入口。

用法：
  python run.py problems/straight3_black_alive.txt
  python run.py problems/l_group.txt --katago katago.exe --config gtp.cfg --model kata1.bin.gz
  python run.py --selftest
"""
import argparse
import glob
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

from tsumego import DFPNSolver, PROVEN, DISPROVEN, TsumegoCoach, load_problem  # noqa: E402

RESULT_CN = {PROVEN: "黑死", DISPROVEN: "黑活"}


def run_selftest(node_limit, problems_dir):
    files = sorted(glob.glob(os.path.join(problems_dir, "*.txt")))
    if not files:
        print("没有找到题目文件")
        return 1
    print(f"{'题目':<28}{'预期':<6}{'证明结果':<8}{'节点':>9}{'用时':>8}  判定")
    print("-" * 72)
    ok = 0
    for f in files:
        prob = load_problem(f)
        board = prob.make_board()
        solver = DFPNSolver(board, node_limit)
        result, _pv = solver.solve()
        got = {PROVEN: "dead", DISPROVEN: "alive"}.get(result)
        passed = (prob.expected is None) or (got == prob.expected)
        ok += bool(passed)
        mark = "PASS" if passed else "FAIL"
        print(
            f"{prob.title:<28}"
            f"{prob.expected or '-':<6}"
            f"{RESULT_CN.get(result, '未知'):<8}"
            f"{solver.nodes:>9}"
            f"{solver.elapsed:>7.2f}s  {mark}"
            f"{'  (劫/循环过滤 %d 次)' % solver.ko_filtered if solver.ko_filtered else ''}"
        )
    print("-" * 72)
    print(f"{ok}/{len(files)} 通过")
    return 0 if ok == len(files) else 1


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(
        description="绝对正确死活教练（df-pn 证明 + 可选 KataGo 混合）"
    )
    ap.add_argument("problem", nargs="?", help="题目文件路径")
    ap.add_argument("--selftest", action="store_true", help="跑 problems/ 下全部题目并核对")
    ap.add_argument("--nodes", type=int, default=1000000, help="df-pn 节点预算（默认 100 万）")
    ap.add_argument("--katago", help="katago 可执行文件路径")
    ap.add_argument("--config", help="KataGo GTP 配置文件")
    ap.add_argument("--model", help="KataGo 网络权重文件（.bin.gz）")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(run_selftest(min(args.nodes, 500000), os.path.join(here, "problems")))

    if not args.problem:
        ap.print_help()
        sys.exit(2)
    if not os.path.isfile(args.problem):
        print(f"找不到题目文件：{args.problem}")
        sys.exit(2)

    prob = load_problem(args.problem)

    bridge = None
    if args.katago:
        if not (args.config and args.model):
            print("连接 KataGo 需要同时提供 --config 与 --model")
            sys.exit(2)
        from tsumego.katago_bridge import KataGoBridge

        try:
            bridge = KataGoBridge(args.katago, args.config, args.model, prob.size)
            print(f"已连接 KataGo（混合模式：策略排序 + 非证明参考）\n")
        except Exception as e:
            print(f"连接 KataGo 失败（回退纯证明模式）：{e}\n")

    coach = TsumegoCoach(prob, bridge=bridge, node_limit=args.nodes)
    coach.repl()


if __name__ == "__main__":
    main()
